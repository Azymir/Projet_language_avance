
#include <QDebug>
#include "widget.h"
#include "graphique.h"
#include "tableau_bord.h"
#include "vanne.h"
#include "pompe.h"
#include "moteur.h"
#include "reservoir.h"
#include "tableau_bord.h"
#include "QtGlobal"

#include <QApplication>
#include <QTextStream>
#include <QInputDialog>
#include <QIODevice>
#include <QString>
#include <QFile>
#include <QMessageBox>
#include"identification.h"







#include "mainwindow.h"
#include <QApplication>
#include "widget.h"
#include "graphique.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    graphique g;
    MainWindow ww;
    ww.show();



    return a.exec();
}





